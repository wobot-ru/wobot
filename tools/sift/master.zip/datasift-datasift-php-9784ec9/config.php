<?php

define('USERNAME', '<your_username>');
define('API_KEY', '<your_api_key>');
