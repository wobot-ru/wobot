CREATE USER 'courtney'@'courtney0' IDENTIFIED BY 'courtney';
GRANT SELECT,INSERT,UPDATE,DELETE,CREATE,DROP ON courtney0.*  TO 'courtney'@'courtney0';