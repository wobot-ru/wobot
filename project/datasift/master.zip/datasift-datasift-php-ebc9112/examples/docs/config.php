<?php
define('USERNAME', 'username');
define('API_KEY', 'api_key');